/**
 * 
 */

function loginPageRedirect(){
	window.location.href = window.location.origin + "/clipshuffler/login.html";
}

function registerPageRedirect() {
	window.location.href = window.location.origin + "/clipshuffler/register.html";
}

function goToUpload() {
	window.location.href = window.location.origin + "/clipshuffler/upload.html";
}