function uploadVideo() {
	// Get the file input element and the file
	var fileInput = document.getElementById('videoFile');
	var file = fileInput.files[0];
	
	// Prepare the form data to send
	var formData = new FormData();
	formData.append('videoFile', file);

	// Create an XMLHttpRequest to send the file
	console.log("uploadVideo?userID=" + localStorage.getItem("id"));
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'uploadVideo?userID=' + localStorage.getItem("id"), true);
	// Set up a callback function to handle the response

	xhr.onload = function () {
		if (xhr.status === 200) {
			// On success, get the response (file path) and display it under the upload button
			var fileLink = xhr.responseText;
			document.getElementById('filePath').innerText = 'Video uploaded: ' + fileLink;
			
			// add one row for the vidoetables
			var table = document.getElementById('videoTable');
			var row = table.insertRow();
            var id = row.insertCell(0);
            var filename = row.insertCell(1);
			
			id.innerHTML = table.rows.length - 2;
			filename.innerHTML = file.name;
			
			// let txt = "";
			// txt = "<tr>" + file.name + "</tr>";
			// document.getElementById('videoTable').innerHTML = txt;
			
		} else if(xhr.status === 409){ // file already existed error
			document.getElementById('filePath').innerText = xhr.responseText;
		} else {
			alert('Error uploading file.');
		}
	};
	// Send the form data with the file to the server
	xhr.send(formData);
}

function combineVideo() {
	console.log("Combine Video Servlet loading...");
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'combineVideo?userID=' + localStorage.getItem("id"), true);
	xhr.send();
	
	xhr.onload = function() {
		if (xhr.status === 200) {
			// On success, get the response (file path) and display it
			console.log("Combine Video Servlet loaded.");
			alert("Videos combined.");
		} else {
			alert('Servlet did not load.');
		}
	}
}

function downloadVideo() {
	console.log("Download Video Servlet loading...");
	var xhr = new XMLHttpRequest();
	console.log("UserID = " + localStorage.getItem("id"));
	xhr.open('GET', 'download?userID=' + localStorage.getItem("id"), true);
	xhr.send();
}

function logout() {
	localStorage.setItem("id", -1);
	window.location.href = window.location.origin + "/clipshuffler/index.html";
	console.log("Logged out.");
}

function returnTo() {
	window.location.href = window.location.origin + "/clipshuffler/index.html";
}