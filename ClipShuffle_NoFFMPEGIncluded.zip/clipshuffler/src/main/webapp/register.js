/**
 * 
 */

const createAccountButton = document.getElementById('loginbutton');

createAccountButton.addEventListener('click', async () => {

    const username = document.getElementById('usernameinput').value.trim();
    const email = document.getElementById('emailinput').value.trim();
    const password = document.getElementById('passwordinput').value.trim();
    const confirmPassword = document.getElementById('confirmpasswordinput').value.trim();
	
	console.log(username);
	console.log(email);
	console.log(password);
	console.log(confirmPassword);


    if (!username || !email || !password || !confirmPassword) {
        alert('All fields are required. Please fill out the form completely.');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match. Please confirm your password.');
        return;
    }
	
	let baseURL = window.location.origin + "/clipshuffler/";

	var url = new URL("register", baseURL);
	
	var params = {
		username: username,
		email: email,
		password: password
	}
	
	url.search = new URLSearchParams(params).toString();

    try {

        const response = await fetch(url, {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
    },
});



        if (!response.ok) {
            const errorMessage = await response.text();
            alert(errorMessage);
            return;
        }

        const result = await response.text();
        alert(result); 
		
		var url2 = new URL("GetID", baseURL);
		var params2 = {
			username: username,
		}

		url2.search = new URLSearchParams(params2).toString();

		try {

		    const response2 = await fetch(url2, {
		method: 'GET',
		headers: {
		    'Content-Type': 'application/json',
		},
		});
		
		if (!response2.ok) {
			return;
		}
		
		const result2 = await response2.text();
		console.log(result2);
		localStorage.setItem('id', result2);
		window.location.href = window.location.origin + "/clipshuffler/upload.html";

		}



		catch (error) {
		        console.error('Error during registration:', error);
		        alert('An error occurred while creating your account. Please try again later.');
		    }	
			
    } catch (error) {
        console.error('Error during registration:', error);
        alert('An error occurred while creating your account. Please try again later.');
    }
});