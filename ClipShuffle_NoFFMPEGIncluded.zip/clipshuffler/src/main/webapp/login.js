/**
 * 
 */

/**
 * 
 */

const createAccountButton = document.getElementById('loginbutton');

createAccountButton.addEventListener('click', async () => {

    const username = document.getElementById('usernameinput').value.trim();
    const password = document.getElementById('passwordinput').value.trim();

    if (!username || !password) {
        alert('All fields are required. Please fill out the form completely.');
        return;
    }
	
	let baseURL = window.location.origin + "/clipshuffler/";

	var url = new URL("login", baseURL);
	
	var params = {
		username: username,
		password: password
	}
	
	url.search = new URLSearchParams(params).toString();

    try {

        const response = await fetch(url, {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json',
    },
	});

		console.log(response.status); //should be 200
        if (!response.ok) {
            const errorMessage = await response.text();
            alert("Error: " + errorMessage);
            return;
        }

        const result = await response.text();
        alert(result); 
		
		var url2 = new URL("GetID", baseURL);
		var params2 = {
			username: username,
		}

		url2.search = new URLSearchParams(params2).toString();
		
		try {
		
		    const response2 = await fetch(url2, {
		method: 'GET',
		headers: {
		    'Content-Type': 'application/json',
		},
		});
		
		if (!response2.ok) {
			console.log("Unsuccessful");
		    return;
		}
		
		const result2 = await response2.text();
		console.log(result2);
		localStorage.setItem('id', result2);
		window.location.href = window.location.origin + "/clipshuffler/upload.html";
		
		
		}
		
		
		
		catch (error) {
		        console.error('Error during login:', error);
		        alert('An error occurred while logging into your account. Please try again later.');
		    }	

		
    } catch (error) {
        console.error('Error during login:', error);
        alert('An error occurred while logging into your account. Please try again later.');
    }
});