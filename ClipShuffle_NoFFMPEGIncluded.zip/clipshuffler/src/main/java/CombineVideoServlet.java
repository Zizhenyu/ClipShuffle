import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/combineVideo")
public class CombineVideoServlet extends HttpServlet {
	
	private static final long serialVersionUID = 102;
	//private static final String FFMPEG_DIR = "/Users/miscby/eclipse-workspace/clipshuffler/src/main/java/ffmpeg";
	private static final String CUR_PATH = CombineVideoServlet.class.getResource("").getPath();
	private static final String FFMPEG_DIR = CombineVideoServlet.class.getResource("").getPath() + "ffmpeg";
	private static final String VID_NAME = "sarahminecraft.mp4";
	private static final String TEMP_DIR = "temp";
	private static final String UPLOAD_DIR = "uploads";
	

	@SuppressWarnings("deprecation")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		File f = new File(CUR_PATH + "videos.txt");
		if (f.createNewFile()) {
	        System.out.println("File created: " + f.getName());
	     }
		FileWriter fw = new FileWriter(f); 
		*/
		
		/*fw.write("file /Users/miscby/Downloads/sarahminecraft.mp4'\r\n");
		fw.write("file /Users/miscby/Downloads/sarahminecraftzombie.mp4'\r\n");
		fw.close();*/
		
		//System.out.println("Upload Video Servlet");
		
		System.out.println("Combine Video Servlet");
		int userId = Integer.parseInt(request.getParameter("userID"));
        System.out.println("UserID = " + userId);
        
		String VIDEO_PATH = getServletContext().getRealPath("") + File.separator + FFMPEG_DIR;
		//String DEST_PATH = getServletContext().getRealPath("") + TEMP_DIR +  File.separator + "output.mp4";
		String DEST_PATH2 = getServletContext().getRealPath("") + TEMP_DIR +  File.separator + "merged.mp4";
		String TXT_PATH2 = getServletContext().getRealPath("") + TEMP_DIR +  File.separator + "videoList.txt";
		if (userId >= 0) {
			DEST_PATH2 = getServletContext().getRealPath("") + UPLOAD_DIR + File.separator + userId + File.separator + "merged.mp4";
			TXT_PATH2 = getServletContext().getRealPath("") + UPLOAD_DIR + File.separator + userId + File.separator + "videoList.txt";
		}
		
		//String cmd = FFMPEG_DIR + " -i" + VIDEO_PATH + " -c copy " + DEST_PATH;
		//String arg = " -i" + VIDEO_PATH + " -c copy " + DEST_PATH;
		System.out.println("Cur Path: " + CUR_PATH);
		System.out.println(VIDEO_PATH);
		System.out.println(FFMPEG_DIR);
		//System.out.println(DEST_PATH);

		//String[] cmd = {FFMPEG_DIR, " -i" + VIDEO_PATH, " -c copy ", DEST_PATH};
		//ProcessBuilder ffmpeg = new ProcessBuilder(FFMPEG_DIR, cmd);
		//Process ffmpeg_p = ffmpeg.start();
		
		//String[] args = new String[] {"/bin/bash", "-c", "ffmpeg", "with", cmd};
		//Process proc = new ProcessBuilder(args).start();
		
		
		//CONCATENATES ALL VIDEOS
		Runtime.getRuntime().exec(FFMPEG_DIR + " -f concat -safe 0 -i " + TXT_PATH2 + " -c copy " + DEST_PATH2);
		//Runtime.getRuntime().exec(FFMPEG_DIR + " -i /Users/miscby/Downloads/sarahminecraftzombie.mp4 -c copy " + DEST_PATH);
		
		
		
		//delete video at end
		//TODO: TRANSFER TO FRONT END
		
		
		//TODO: DELETE FILE
		//output.delete();
		System.out.println("Successfully copied video.");
	}
}
