import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
	
	private static final long serialVersionUID = 102;
	//private static final String FFMPEG_DIR = "/Users/miscby/eclipse-workspace/clipshuffler/src/main/java/ffmpeg";
	private static final String CUR_PATH = CombineVideoServlet.class.getResource("").getPath();
	private static final String FFMPEG_DIR = CombineVideoServlet.class.getResource("").getPath() + "ffmpeg";
	private static final String VID_NAME = "sarahminecraft.mp4";
	private static final String TEMP_DIR = "temp";
	private static final String UPLOAD_DIR = "uploads";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Download Servlet");
    	int userId = Integer.parseInt(request.getParameter("userID"));
    	System.out.println(userId);
		
		String DEST_PATH2 = getServletContext().getRealPath("") + TEMP_DIR +  File.separator + "merged.mp4";
		if (userId >= 0) DEST_PATH2 = getServletContext().getRealPath("") + UPLOAD_DIR +  File.separator + userId + File.separator + "merged.mp4";
		
		File output = new File(DEST_PATH2);
		
		
		OutputStream os = response.getOutputStream();
		response.setContentType("video/mp4");
		response.setHeader("Content-Disposition", "attachment; filename=\"" + DEST_PATH2 + "\"");
		FileInputStream fis = new FileInputStream(output);
		
		byte[] buffer = new byte[4096];
		int length;
		while ((length = fis.read(buffer)) > 0){
		    os.write(buffer, 0, length);
		}
		os.flush();
		fis.close();
		os.close();
		System.out.println("File successfully downloaded.");
	}
	
}
