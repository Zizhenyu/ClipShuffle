import java.io.*;
import java.util.Vector;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/getTable")
public class getTable extends HttpServlet {
	
	//private static final String FFMPEG_DIR = "/Users/miscby/eclipse-workspace/clipshuffler/src/main/java/ffmpeg";
	/*private static final String CUR_PATH = CombineVideoServlet.class.getResource("").getPath();
	private static final String FFMPEG_DIR = CombineVideoServlet.class.getResource("").getPath() + "ffmpeg";
	private static final String VID_NAME = "sarahminecraft.mp4";
	private static final String TEMP_DIR = "temp";*/
	private static final String UPLOAD_DIR = "uploads";
	Vector<String> vid_list = new Vector<String>();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("getTable servlet");
    	int userId = Integer.parseInt(request.getParameter("userID"));
    	System.out.println(userId);
		
		String DEST_PATH2 = getServletContext().getRealPath("") + UPLOAD_DIR +  File.separator + userId + File.separator + "videos.txt";
		File f = new File(DEST_PATH2);
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);
		
		String ret = "{\"filenames\": [";
		String nextLine = br.readLine();
		while (nextLine != null) {
			//ret += "\"" + nextLine.substring(5, nextLine.length() - 1) + "\",";
			ret += "\"" + nextLine + "\",";
			vid_list.add(nextLine);
			nextLine = br.readLine();
		}
		ret = ret.substring(0, ret.length() - 1);
		ret += "]}";
		System.out.println(ret);
		
		
		response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        pw.print(ret);
        pw.close();
	}
	
}
