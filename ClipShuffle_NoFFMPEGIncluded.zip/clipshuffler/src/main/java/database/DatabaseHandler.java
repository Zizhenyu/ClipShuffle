package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseHandler {
    private static final String DB_URL = "jdbc:mysql://localhost/team20database";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "doremiharukaze";
    
    public DatabaseHandler() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
    }

    public static String addToDatabase(String username, String password, String email) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryInsertUser = "INSERT INTO UserInfo (Username, Pasword, Email, Workspace) VALUES (?, ?, ?, '')";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(queryInsertUser)) {

            stmt.setString(1, username);
            stmt.setString(2, password); // Use hashing in production
            stmt.setString(3, email);

            stmt.executeUpdate();
            return "User successfully registered.";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    public static String validateLogin(String username, String password) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryValidate = "SELECT Pasword FROM UserInfo WHERE Username = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(queryValidate)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("Pasword");
                return storedPassword.equals(password) ? "Login successful!" : "Invalid credentials.";
            } else {
                return "User not found.";
            }
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    public static String addWorkspaceToDatabase(String username, String workspace) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryUpdate = "UPDATE UserInfo SET Workspace = ? WHERE Username = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(queryUpdate)) {

            stmt.setString(1, workspace);
            stmt.setString(2, username);

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0 ? "Workspace updated successfully." : "Username not found.";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }
    
    public static String connectUsers(String username) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryFindUser = "SELECT UserID FROM UserInfo WHERE Username = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement findStmt = conn.prepareStatement(queryFindUser)) {

            // Check if the user exists
            findStmt.setString(1, username);
            ResultSet rs = findStmt.executeQuery();

            if (rs.next()) {
                int existingUserID = rs.getInt("UserID");
                return "User " + username + " is already connected with UserID: " + existingUserID;
            } else {
                return "User " + username + " does not exist.";
            }

        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }
    
    public static int getId(String username) {
    	int userID = -1;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryFindUser = "SELECT UserID FROM UserInfo WHERE Username = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement findStmt = conn.prepareStatement(queryFindUser)) {

        	findStmt.setString(1, username);
            ResultSet rs = findStmt.executeQuery();

            if (rs.next()) {
                userID = rs.getInt("UserID");
            }

        } catch (SQLException e) {
            return -1;
        }    
        
        return userID;
    }
    
    public static String getUsername(String id) {
    	String username = "Guest";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {}
        String queryFindUser = "SELECT * FROM UserInfo WHERE UserID = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement findStmt = conn.prepareStatement(queryFindUser)) {

        	findStmt.setString(1, id);
            ResultSet rs = findStmt.executeQuery();

            if (rs.next()) {
                username = rs.getString("Username");
            }

        } catch (SQLException e) {
            return username;
        }    
        
        return username;   	
    }

}
