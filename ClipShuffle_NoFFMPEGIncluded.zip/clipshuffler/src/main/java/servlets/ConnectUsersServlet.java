package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import database.DatabaseHandler;

import java.io.IOException;

@WebServlet("/connectUser")
public class ConnectUsersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract username from request
        String username = request.getParameter("username");

        // Validate input
        if (username == null || username.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Error: Username cannot be null or empty.");
            return;
        }

        // Call DatabaseHandler to connect user
        String result = DatabaseHandler.connectUsers(username);

        // Respond to the client
        response.setContentType("text/plain");
        response.getWriter().write(result);
    }
}
