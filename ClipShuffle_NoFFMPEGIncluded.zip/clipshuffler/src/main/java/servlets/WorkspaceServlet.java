package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import database.DatabaseHandler;

import java.io.IOException;

@WebServlet("/updateWorkspace")
public class WorkspaceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract user input
        String username = request.getParameter("username");
        String workspace = request.getParameter("workspace");

        // Validate input
        if (username == null || username.trim().isEmpty() ||
            workspace == null || workspace.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Error: Username and workspace cannot be null or empty.");
            return;
        }

        // Call DatabaseHandler to update the workspace
        String result = DatabaseHandler.addWorkspaceToDatabase(username, workspace);

        // Respond to the client
        response.setContentType("text/plain");
        response.getWriter().write(result);
    }
}
