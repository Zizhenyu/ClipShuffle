package servlets;

import java.io.IOException;

import database.DatabaseHandler;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract user input
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        // Validate input
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Error: All fields (username, password) are required.");
            return;
        }

        // Call DatabaseHandler to add user
        String result = DatabaseHandler.validateLogin(username, password);
        
        if (result.compareTo("Invalid credentials.") == 0 || result.compareTo("User not found.") == 0) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write(result);
            return;
        }
        
        
        response.setStatus(HttpServletResponse.SC_OK);
        System.out.println(200);
        // Respond to the client
        response.setContentType("text/plain");
        response.getWriter().write(result);
    }
}
