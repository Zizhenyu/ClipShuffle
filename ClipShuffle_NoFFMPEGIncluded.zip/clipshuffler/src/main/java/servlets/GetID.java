package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.google.gson.Gson;

import database.DatabaseHandler;

/**
 * Servlet implementation class GetID
 */
@WebServlet("/GetID")
public class GetID extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetID() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract user input
        String username = request.getParameter("username");
        
        Gson gson = new Gson();
        
        // Validate input
        if (username == null || username.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Error: All fields (username) are required.");
            return;
        }

        // Call DatabaseHandler to add user
        int userID = DatabaseHandler.getId(username);
        
        response.setStatus(HttpServletResponse.SC_OK);
        // Respond to the client
        response.setContentType("text/plain");
        response.getWriter().write(gson.toJson(userID));
    }


}
